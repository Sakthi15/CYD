﻿using Sample_Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace Sample_Project.Controllers
{
    public class HomeController : Controller
    {

    //Creating object for the DataBase Entity
        CYDDatabaseEntities db = new CYDDatabaseEntities();

    //Creating the action method for Dashboard
        public ActionResult Dashboard()
        {
            return View();
        }


//********************************************Hospitial Fun Start***********************************************

    //Creating the action method for Hospitals 
        public ActionResult Hospitals()
        {
            //retuns the Hospitals table data from database to Hospitals view
            return View(db.Hospitals.ToList());
        }


    //Creating the action method for GetSearchingHosData and returns the JsonResult to hospital view
        [HttpPost]
        public JsonResult GetSearchingHosData(string SearchBy, string SearchValue)
        {
            //creating the Hospitals List
            List<Hospital> HosList = new List<Hospital>();

            //Search by with name.
            if (SearchBy == "Name")
            {
                //Checking the search value in the Hospitals database by using contains functionality and store the data in list format.
                HosList = db.Hospitals.Where(x => x.h_name.Contains(SearchValue) || SearchValue == null).ToList();
                return Json(HosList, JsonRequestBehavior.AllowGet);
            }
            //Search by with Hospital Type.
            else if (SearchBy == "Type")
            {
                HosList = db.Hospitals.Where(x => x.h_type.StartsWith(SearchValue) || SearchValue == null).ToList();
                return Json(HosList, JsonRequestBehavior.AllowGet);
            }
            //Search by with Hospital Area.
            else if (SearchBy == "Area")
            {
                HosList = db.Hospitals.Where(x => x.h_area.StartsWith(SearchValue) || SearchValue == null).ToList();
                return Json(HosList, JsonRequestBehavior.AllowGet);
            }
            //Search by with Hospital City.
            else
            {
                HosList = db.Hospitals.Where(x => x.h_city.StartsWith(SearchValue) || SearchValue == null).ToList();
                return Json(HosList, JsonRequestBehavior.AllowGet);
            }
        }

//********************************************Hospitial Fun End************************************************




//********************************************Banks Fun Start***************************************************

    //Creating the action method for Banks
        public ActionResult Banks()
        {
            //retuns the banks table data from database to banks view
            return View(db.Banks.ToList());
        }


    //Creating the action method for GetSearchingBankData and returns the JsonResult to Banks view
        public JsonResult GetSearchingBankData(string SearchBy, string SearchValue)
        {
            //creating the Banks List
            List<Bank> BankList = new List<Bank>();
            //Search by with Banks Name.
            if (SearchBy == "Name")
            {
                //Checking the search value in the Banks database by using contains functionality and store the data in list format.
                BankList = db.Banks.Where(x => x.bank_name.Contains(SearchValue) || SearchValue == null).ToList();
                return Json(BankList, JsonRequestBehavior.AllowGet);
            }
            //Search by with Banks Branch Name.
            else if (SearchBy == "BName")
            {
                BankList = db.Banks.Where(x => x.branch_name.StartsWith(SearchValue) || SearchValue == null).ToList();
                return Json(BankList, JsonRequestBehavior.AllowGet);
            }
            //Search by with Banks IFSCCode.
            else if (SearchBy == "IFSCCode")
            {
                BankList = db.Banks.Where(x => x.ifsc_code.StartsWith(SearchValue) || SearchValue == null).ToList();
                return Json(BankList, JsonRequestBehavior.AllowGet);
            }
            //Search by with Banks City.
            else
            {
                BankList = db.Banks.Where(x => x.bank_city.StartsWith(SearchValue) || SearchValue == null).ToList();
                return Json(BankList, JsonRequestBehavior.AllowGet);
            }
        }

//********************************************Banks Fun End***************************************************




//********************************************Restaurants Fun Start*******************************************

    //Creating the action method for Restaurants
        public ActionResult Restaurants()
        {
            //retuns the Restaurants table data from database to Restaurants view
            return View(db.Restaurants.ToList());
        }


    //Creating the action method for GetSearchingResData and returns the JsonResult to Restaurants view
        public JsonResult GetSearchingResData(string SearchBy, string SearchValue)
        {
            List<Restaurant> ResList = new List<Restaurant>();
            //Search by with Restaurants Name.
            if (SearchBy == "Name")
            {
                //Checking the search value in the Restaurants database by using contains functionality and store the data in list format.
                ResList = db.Restaurants.Where(x => x.r_name.Contains(SearchValue) || SearchValue == null).ToList();
                return Json(ResList, JsonRequestBehavior.AllowGet);
            }
            //Search by with Restaurants Type.
            else if (SearchBy == "Type")
            {
                ResList = db.Restaurants.Where(x => x.r_type.StartsWith(SearchValue) || SearchValue == null).ToList();
                return Json(ResList, JsonRequestBehavior.AllowGet);
            }
            //Search by with Restaurants Area.
            else if (SearchBy == "Area")
            {
                ResList = db.Restaurants.Where(x => x.r_area.StartsWith(SearchValue) || SearchValue == null).ToList();
                return Json(ResList, JsonRequestBehavior.AllowGet);
            }
            //Search by with Restaurants City.
            else if (SearchBy == "City")
            {
                ResList = db.Restaurants.Where(x => x.r_city.StartsWith(SearchValue) || SearchValue == null).ToList();
                return Json(ResList, JsonRequestBehavior.AllowGet);
            }
            //Search by with Restaurants Ratings.
            else
            {
                ResList = db.Restaurants.Where(x => x.r_rating.Equals(SearchValue) || SearchValue == null).ToList();
                return Json(ResList, JsonRequestBehavior.AllowGet);
            }
        }


//********************************************Restaurants Fun End***********************************************




//********************************************Grocery Stores Fun Start******************************************

    //Creating the action method for Grocery Stores
        public ActionResult GroceryStores()
        {
            //retuns the GroceryStores table data from database to GroceryStores view
            return View(db.Grocery_Stores.ToList());
        }


    //Creating the action method for GetSearchingGroData and returns the JsonResult to GroceryStores view
        public JsonResult GetSearchingGroData(string SearchBy, string SearchValue)
        {
            List<Grocery_Stores> GroList = new List<Grocery_Stores>();
            //Search by with Grocery Stores Name.
            if (SearchBy == "Name")
            {
                //Checking the search value in the Grocery Stores database by using contains functionality and store the data in list format.
                GroList = db.Grocery_Stores.Where(x => x.g_name.Contains(SearchValue) || SearchValue == null).ToList();
                return Json(GroList, JsonRequestBehavior.AllowGet);
            }
            //Search by with Grocery Stores Area.
            else if (SearchBy == "Area")
            {
                GroList = db.Grocery_Stores.Where(x => x.g_area.StartsWith(SearchValue) || SearchValue == null).ToList();
                return Json(GroList, JsonRequestBehavior.AllowGet);
            }
            //Search by with Grocery Stores City.
            else if (SearchBy == "City")
            {
                GroList = db.Grocery_Stores.Where(x => x.g_city.StartsWith(SearchValue) || SearchValue == null).ToList();
                return Json(GroList, JsonRequestBehavior.AllowGet);
            }
            //Search by with Grocery Stores Ratings.
            else
            {
                GroList = db.Grocery_Stores.Where(x => x.g_rating.Equals(SearchValue) || SearchValue == null).ToList();
                return Json(GroList, JsonRequestBehavior.AllowGet);
            }
        }

//********************************************Grocery Stores Fun End******************************************




//********************************************Fuel Station Fun Start******************************************


    //Creating the action method for Fuel Station
        public ActionResult FuelStation()
        {
            //retuns the FuelStation table data from database to FuelStation view
            return View(db.Fuel_Station.ToList());
        }


    //Creating the action method for GetSearchingFuelData and returns the JsonResult to FuelStation view
        public JsonResult GetSearchingFuelData(string SearchBy, string SearchValue)
        {
            List<Fuel_Station> FuelList = new List<Fuel_Station>();
            //Search by with FuelStation Name.
            if (SearchBy == "Name")
            {
                //Checking the search value in the Fuel Station database by using contains functionality and store the data in list format.
                FuelList = db.Fuel_Station.Where(x => x.f_name.Contains(SearchValue) || SearchValue == null).ToList();
                return Json(FuelList, JsonRequestBehavior.AllowGet);
            }
            //Search by with FuelStation Area.
            else if (SearchBy == "Area")
            {
                FuelList = db.Fuel_Station.Where(x => x.f_area.StartsWith(SearchValue) || SearchValue == null).ToList();
                return Json(FuelList, JsonRequestBehavior.AllowGet);
            }
            //Search by with FuelStation City.
            else
            {
                FuelList = db.Fuel_Station.Where(x => x.f_city.StartsWith(SearchValue) || SearchValue == null).ToList();
                return Json(FuelList, JsonRequestBehavior.AllowGet);
            }
        }

//********************************************Fuel Station Fun End*********************************************




//********************************************Weather Forecast Fun Start****************************************

    //Creating the action method for Weather Forecast
        public ActionResult WeatherForecast()
        {
            //retuns the WeatherForecast table data from database to WeatherForecast view
            return View(db.Weather_Forecast.ToList());
        }


    //Creating the action method for GetSearchingWeaData and returns the JsonResult to WeatherForecast view
        public JsonResult GetSearchingWeaData(string SearchBy, string SearchValue)
        {
            List<Weather_Forecast> WeaList = new List<Weather_Forecast>();
            //Search by with WeatherForecast PinCode
            if (SearchBy == "PinCode")
            {
                //Checking the search value in the Weather Forecast database by using StartsWith functionality and store the data in list format.
                WeaList = db.Weather_Forecast.Where(x => x.w_pincode.StartsWith(SearchValue) || SearchValue == null).ToList();
                return Json(WeaList, JsonRequestBehavior.AllowGet);
            }
            //Search by with WeatherForecast State
            else if (SearchBy == "State")
            {
                WeaList = db.Weather_Forecast.Where(x => x.w_state.StartsWith(SearchValue) || SearchValue == null).ToList();
                return Json(WeaList, JsonRequestBehavior.AllowGet);
            }
            //Search by with WeatherForecast Area
            else if (SearchBy == "Area")
            {
                WeaList = db.Weather_Forecast.Where(x => x.w_area.StartsWith(SearchValue) || SearchValue == null).ToList();
                return Json(WeaList, JsonRequestBehavior.AllowGet);
            }
            //Search by with WeatherForecast City
            else
            {
                WeaList = db.Weather_Forecast.Where(x => x.w_city.StartsWith(SearchValue) || SearchValue == null).ToList();
                return Json(WeaList, JsonRequestBehavior.AllowGet);
            }
        }

//********************************************Weather Forecast Fun End****************************************



    //Creating the action method for AboutUs
        public ActionResult AboutUs()
        {
            return View();
        }

    }
}